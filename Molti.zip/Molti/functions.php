<?php if( file_exists( get_stylesheet_directory().'/jedi-apprentice/jedi-apprentice-import.php' ) && !defined('JEDI_APPRENTICE_PATH') ) {include_once( get_stylesheet_directory().'/jedi-apprentice/jedi-apprentice-import.php' );} ?><?php

//Getting all styles and scripts
///// Gettings CSS
function molti_enqueue_styles() { 
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'molti_enqueue_styles' );


// Every Divi Layout as Shortcode with the Below Code

add_filter( 'manage_et_pb_layout_posts_columns', 'sj_create_shortcode_column', 5 );
add_action( 'manage_et_pb_layout_posts_custom_column', 'sj_shortcode_content', 5, 2 );
// register new shortcode
add_shortcode('sj_layout', 'sj_shortcode_mod');
// New Admin Column
function sj_create_shortcode_column( $columns ) {
$columns['sj_shortcode_id'] = 'Module Shortcode';
return $columns;
}
//Display Shortcode
function sj_shortcode_content( $column, $id ) {
if( 'sj_shortcode_id' == $column ) {
?>
<p>[sj_layout id="<?php echo $id ?>"]</p>
<?php
}
}
// Create New Shortcode
function sj_shortcode_mod($sj_mod_id) {
extract(shortcode_atts(array('id' =>'*'),$sj_mod_id));
return do_shortcode('[et_pb_section global_module="'.$id.'"][/et_pb_section]');
}



// ====================== Molti Customizer Settings ======================

function starter_customize_register( $wp_customize ) 
{

    $wp_customize->add_panel('molti_panel',array(
    'title'=>'Molti',
    'priority'=> 0,
    ) );

    $wp_customize->add_section( 'accent_color' , array(
        'title'    => __( 'Molti Accent Colors', 'starter' ),
        'priority' => 0,
        'panel'=>'molti_panel',
    ) );  

    
     $wp_customize->add_setting( 'accent_color_setting' , array(
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'accent_color_control', array(
        'label'    => __( 'Accent Color', 'starter' ),
		'description'    => __( 'Easily Change the Color Scheme of your site, This allows you to change most of the Molti Orange Colors to your Brand Colors easily.'),
        'section'  => 'accent_color',
        'settings' => 'accent_color_setting',
        
    ) ) );
	
	$wp_customize->add_setting( 'top_bar_color_setting' , array(
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ) );
	
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'top_bar_color_control', array(
        'label'    => __( 'Top Bar Color', 'starter' ),
		'description'    => __( 'Here you can Change the Top Bar Color in the Main Header of the site.'),
        'section'  => 'accent_color',
        'settings' => 'top_bar_color_setting',
        
    ) ) );
    
    }

function molti_accent_color_change() {
echo '<style type="text/css">


/*Color*/

div > div > div > div.et_pb_section.et_pb_section_2.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_4 > div.et_pb_with_border.et_pb_column_1_3.et_pb_column.et_pb_column_7.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_3.et_pb_text_align_left.et_pb_bg_layout_light > div > h1 > span:nth-child(1), div > div > div > div.et_pb_section.et_pb_section_0.et_pb_with_background.et_section_regular > div > div.et_pb_column.et_pb_column_1_2.et_pb_column_0.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_0.et_pb_text_align_left.et_pb_bg_layout_light > div > h1 > span:nth-child(2) > strong > span, div > div > div > div.et_pb_section.et_pb_section_1.our-services-section.et_section_regular > div.et_pb_row.et_pb_row_1 > div > div > div > h1 > span, div > div > div > div.et_pb_section.et_pb_section_2.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_3 > div > div > div > h1 > span, div > div > div > div.et_pb_section.et_pb_section_2.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_4 > div.et_pb_with_border.et_pb_column_1_3.et_pb_column.et_pb_column_7.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_3.et_pb_text_align_left.et_pb_bg_layout_light > div > h1 > span:nth-child(2), div > div > div > div.et_pb_section.et_pb_section_3.et_section_regular > div.et_pb_row.et_pb_row_5 > div > div.et_pb_module.et_pb_text.et_pb_text_4.et_pb_text_align_left.et_pb_bg_layout_light > div > h3, div > div > div > div.et_pb_section.et_pb_section_4.features-section.et_section_regular > div.et_pb_row.et_pb_row_7 > div > div.et_pb_module.et_pb_text.et_pb_text_5.et_pb_text_align_left.et_pb_bg_layout_light > div > h1 > span, div > div > div > div.et_pb_section.et_pb_section_5.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_11 > div > div > div > h1 > span, div > div > div > div.et_pb_section.et_pb_section_6.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_15 > div > div > div > h2 > span, div > div > div > div.et_pb_section.et_pb_section_6.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_16 > div.et_pb_column.et_pb_column_1_3.et_pb_column_30.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_8.et_pb_text_align_left.et_pb_bg_layout_light > div > h1, div > div > div > div.et_pb_section.et_pb_section_6.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_16 > div.et_pb_column.et_pb_column_1_3.et_pb_column_31.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_11.et_pb_text_align_left.et_pb_bg_layout_light > div > h1, div > div > div > div.et_pb_section.et_pb_section_6.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_16 > div.et_pb_column.et_pb_column_1_3.et_pb_column_32.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_14.et_pb_text_align_left.et_pb_bg_layout_light > div > h1, div > div > div > div.et_pb_section.et_pb_section_6.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_16 > div.et_pb_column.et_pb_column_1_3.et_pb_column_30.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_9.et_pb_text_align_left.et_pb_bg_layout_light > div > p:nth-child(1) > span, div > div > div > div.et_pb_section.et_pb_section_6.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_16 > div.et_pb_column.et_pb_column_1_3.et_pb_column_30.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_9.et_pb_text_align_left.et_pb_bg_layout_light > div > p:nth-child(2) > span, div > div > div > div.et_pb_section.et_pb_section_6.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_16 > div.et_pb_column.et_pb_column_1_3.et_pb_column_30.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_9.et_pb_text_align_left.et_pb_bg_layout_light > div > p:nth-child(4) > span, div > div > div > div.et_pb_section.et_pb_section_6.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_16 > div.et_pb_column.et_pb_column_1_3.et_pb_column_31.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_12.et_pb_text_align_left.et_pb_bg_layout_light > div > p:nth-child(1) > span, div > div > div > div.et_pb_section.et_pb_section_6.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_16 > div.et_pb_column.et_pb_column_1_3.et_pb_column_31.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_12.et_pb_text_align_left.et_pb_bg_layout_light > div > p:nth-child(2) > span, div > div > div > div.et_pb_section.et_pb_section_6.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_16 > div.et_pb_column.et_pb_column_1_3.et_pb_column_31.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_12.et_pb_text_align_left.et_pb_bg_layout_light > div > p:nth-child(4) > span, div > div > div > div.et_pb_section.et_pb_section_6.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_16 > div.et_pb_column.et_pb_column_1_3.et_pb_column_32.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_15.et_pb_text_align_left.et_pb_bg_layout_light > div > p:nth-child(1) > span, div > div > div > div.et_pb_section.et_pb_section_6.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_16 > div.et_pb_column.et_pb_column_1_3.et_pb_column_32.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_15.et_pb_text_align_left.et_pb_bg_layout_light > div > p:nth-child(2) > span, div > div > div > div.et_pb_section.et_pb_section_6.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_16 > div.et_pb_column.et_pb_column_1_3.et_pb_column_32.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_15.et_pb_text_align_left.et_pb_bg_layout_light > div > p:nth-child(4) > span, div > div > div > div.et_pb_section.et_pb_section_7.et_section_regular > div.et_pb_row.et_pb_row_17 > div > div > div > h1 > span, div > div > div > div.et_pb_section.et_pb_section_7.et_section_regular > div.et_pb_row.et_pb_row_19 > div > div > div > p > a, div > div > div > div.et_pb_section.et_pb_section_8.et_section_regular > div.et_pb_row.et_pb_row_20 > div > div > div > h2 > span, div > div > div > div.et_pb_section.et_pb_section_9.et_section_regular > div > div > div.et_pb_module.et_pb_text.et_pb_text_20.et_pb_text_align_left.et_pb_bg_layout_light > div > h2 > span, .et_pb_blog_0 .et_pb_post:hover .entry-title a, div > div > div > div.et_pb_section.et_pb_section_1.our-services-section.et_section_regular > div.et_pb_row.et_pb_row_2 > div.et_pb_column.et_pb_column_1_3.et_pb_column_3.et_pb_css_mix_blend_mode_passthrough > div > div > div.et_pb_blurb_container > h4, div > div > div > div.et_pb_section.et_pb_section_1.our-services-section.et_section_regular > div.et_pb_row.et_pb_row_2 > div.et_pb_column.et_pb_column_1_3.et_pb_column_4.et_pb_css_mix_blend_mode_passthrough > div > div > div.et_pb_blurb_container > h4, div > div > div > div.et_pb_section.et_pb_section_1.our-services-section.et_section_regular > div.et_pb_row.et_pb_row_2 > div.et_pb_column.et_pb_column_1_3.et_pb_column_5.et_pb_css_mix_blend_mode_passthrough.et-last-child > div > div > div.et_pb_blurb_container > h4, div > div > div > div.et_pb_section.et_pb_section_1.our-services-section.et_section_regular > div.et_pb_row.et_pb_row_2 > div.et_pb_column.et_pb_column_1_3.et_pb_column_3.et_pb_css_mix_blend_mode_passthrough > div > div > div.et_pb_blurb_container > div > p:nth-child(2) > span, div > div > div > div.et_pb_section.et_pb_section_1.our-services-section.et_section_regular > div.et_pb_row.et_pb_row_2 > div.et_pb_column.et_pb_column_1_3.et_pb_column_4.et_pb_css_mix_blend_mode_passthrough > div > div > div.et_pb_blurb_container > div > p:nth-child(2) > span, div > div > div > div.et_pb_section.et_pb_section_1.our-services-section.et_section_regular > div.et_pb_row.et_pb_row_2 > div.et_pb_column.et_pb_column_1_3.et_pb_column_5.et_pb_css_mix_blend_mode_passthrough.et-last-child > div > div > div.et_pb_blurb_container > div > p:nth-child(2) > span,  div > div > div > div.et_pb_section.et_pb_section_0.et_pb_with_background.et_section_regular.section_has_divider.et_pb_bottom_divider > div.et_pb_row.et_pb_row_0.et_pb_equal_columns > div.et_pb_column.et_pb_column_1_2.et_pb_column_0.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_0.et_pb_text_align_left.et_pb_bg_layout_light > div > h1 > span:nth-child(1),  div > div > div > div.et_pb_section.et_pb_section_0.et_pb_with_background.et_section_regular.section_has_divider.et_pb_bottom_divider > div.et_pb_row.et_pb_row_0.et_pb_equal_columns > div.et_pb_column.et_pb_column_1_2.et_pb_column_0.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_0.et_pb_text_align_left.et_pb_bg_layout_light > div > h1 > span:nth-child(3),  div > div > div > div.et_pb_section.et_pb_section_3.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_4 > div > div > div > h1,  div > div > div > div.et_pb_section.et_pb_section_0.et_pb_with_background.et_section_regular.section_has_divider.et_pb_bottom_divider > div.et_pb_row.et_pb_row_0.inline-buttons-row.et_pb_equal_columns > div.et_pb_column.et_pb_column_1_2.et_pb_column_0.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_0.et_pb_text_align_left.et_pb_bg_layout_light > div > h1 > span > strong, #read > div > div.et_pb_column.et_pb_column_1_2.et_pb_column_3.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_2.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, #read > div > div.et_pb_column.et_pb_column_1_2.et_pb_column_3.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_blurb.et_pb_blurb_0.et_pb_text_align_left.et_pb_blurb_position_left.et_pb_bg_layout_light > div > div.et_pb_main_blurb_image > span > span, #read > div > div.et_pb_column.et_pb_column_1_2.et_pb_column_3.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_blurb.et_pb_blurb_1.et_pb_text_align_left.et_pb_blurb_position_left.et_pb_bg_layout_light > div > div.et_pb_main_blurb_image > span > span, #read > div > div.et_pb_column.et_pb_column_1_2.et_pb_column_3.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_blurb.et_pb_blurb_2.et_pb_text_align_left.et_pb_blurb_position_left.et_pb_bg_layout_light > div > div.et_pb_main_blurb_image > span > span,  div > div > div > div.et_pb_section.et_pb_section_3.et_section_regular > div.et_pb_row.et_pb_row_3 > div > div > div > h3 > span,  div > div > div > div.et_pb_section.et_pb_section_3.et_section_regular > div.et_pb_row.et_pb_row_4 > div.et_pb_column.et_pb_column_1_3.et_pb_column_6.member-card.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_7.et_pb_text_align_left.et_pb_bg_layout_light > div > p,  div > div > div > div.et_pb_section.et_pb_section_6.et_section_regular > div.et_pb_row.et_pb_row_16 > div.et_pb_column.et_pb_column_1_3.et_pb_column_29.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_28.et_pb_text_align_left.et_pb_bg_layout_light > div > div > div > div > div > p > span,  div > div > div > div.et_pb_section.et_pb_section_3.et_section_regular > div.et_pb_row.et_pb_row_4 > div.et_pb_column.et_pb_column_1_3.et_pb_column_7.member-card.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_9.et_pb_text_align_left.et_pb_bg_layout_light > div > p,  div > div > div > div.et_pb_section.et_pb_section_3.et_section_regular > div.et_pb_row.et_pb_row_4 > div.et_pb_column.et_pb_column_1_3.et_pb_column_8.member-card.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_11.et_pb_text_align_left.et_pb_bg_layout_light > div > p,  div > div > div > div.et_pb_section.et_pb_section_3.et_section_regular > div.et_pb_row.et_pb_row_5 > div.et_pb_column.et_pb_column_1_3.et_pb_column_9.member-card.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_13.et_pb_text_align_left.et_pb_bg_layout_light > div > p,  div > div > div > div.et_pb_section.et_pb_section_3.et_section_regular > div.et_pb_row.et_pb_row_5 > div.et_pb_column.et_pb_column_1_3.et_pb_column_10.member-card.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_15.et_pb_text_align_left.et_pb_bg_layout_light > div > p,  div > div > div > div.et_pb_section.et_pb_section_3.et_section_regular > div.et_pb_row.et_pb_row_5 > div.et_pb_column.et_pb_column_1_3.et_pb_column_11.member-card.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_17.et_pb_text_align_left.et_pb_bg_layout_light > div > p,  div > div > div > div.et_pb_section.et_pb_section_6.et_section_regular > div.et_pb_row.et_pb_row_16 > div.et_pb_column.et_pb_column_1_3.et_pb_column_30.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_30.et_pb_text_align_left.et_pb_bg_layout_light > div > div > div > div > div > p > span,  div > div > div > div.et_pb_section.et_pb_section_6.et_section_regular > div.et_pb_row.et_pb_row_16 > div.et_pb_column.et_pb_column_1_3.et_pb_column_31.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_32.et_pb_text_align_left.et_pb_bg_layout_light > div > div > div > div > div > p > span, #reveal-1 > div.et_pb_column.et_pb_column_1_3.et_pb_column_32.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_34.et_pb_text_align_left.et_pb_bg_layout_light > div > div > div > div > div > p > span, #reveal-1 > div.et_pb_column.et_pb_column_1_3.et_pb_column_33.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_36.et_pb_text_align_left.et_pb_bg_layout_light > div > div > div > div > div > p > span, #reveal-1 > div.et_pb_column.et_pb_column_1_3.et_pb_column_34.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_38.et_pb_text_align_left.et_pb_bg_layout_light > div > div > div > div > div > p > span,  div > div > div > div.et_pb_section.et_pb_section_0.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_0 > div > div.et_pb_module.et_pb_text.et_pb_text_0.et_pb_text_align_left.et_pb_bg_layout_light > div > h1 > span,  div > div > div > div.et_pb_section.et_pb_section_1.faq-section-contact-page.et_pb_with_background.et_section_regular > div > div > div.et_pb_module.et_pb_text.et_pb_text_9.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span,  div > div > div > div.et_pb_section.et_pb_section_0.et_pb_with_background.et_section_regular.section_has_divider.et_pb_bottom_divider > div.et_pb_row.et_pb_row_0.et_pb_equal_columns > div.et_pb_column.et_pb_column_1_2.et_pb_column_0.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_0.et_pb_text_align_left.et_pb_bg_layout_light > div > h1 > span,  div > div > div > div.et_pb_section.et_pb_section_1.et_pb_with_background.et_section_specialty > div > div.et_pb_column.et_pb_column_1_2.et_pb_column_3.et_pb_css_mix_blend_mode_passthrough.et_pb_column_single > div.et_pb_module.et_pb_text.et_pb_text_3.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span:nth-child(1),  div > div > div > div.et_pb_section.et_pb_section_1.et_pb_with_background.et_section_specialty > div > div.et_pb_column.et_pb_column_1_2.et_pb_column_3.et_pb_css_mix_blend_mode_passthrough.et_pb_column_single > div.et_pb_module.et_pb_text.et_pb_text_3.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span:nth-child(2),  div > div > div > div.et_pb_section.et_pb_section_2.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_1 > div > div.et_pb_module.et_pb_text.et_pb_text_5.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, #jobs > div.et_pb_row.et_pb_row_3 > div > div > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_0.et_pb_with_background.et_section_regular > div > div > div.et_pb_module.et_pb_blurb.et_pb_blurb_0.et_pb_text_align_left.et_pb_blurb_position_left.et_pb_bg_layout_light > div > div.et_pb_main_blurb_image > span > span, #main-content > div > div > div > div > div.et_pb_column.et_pb_column_1_2.et_pb_column_1_tb_body.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_0_tb_body.et_pb_text_align_left.et_pb_bg_layout_light > div > h1 > span, div > div > div > div.et_pb_section.et_pb_section_0.et_pb_with_background.et_section_regular.section_has_divider.et_pb_bottom_divider > div.et_pb_row.et_pb_row_0.inline-buttons-row.et_pb_equal_columns > div.et_pb_column.et_pb_column_1_2.et_pb_column_0.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_0.et_pb_text_align_left.et_pb_bg_layout_light > div > div > div > h1 > span, div > div > div > div.et_pb_section.et_pb_section_1.et_section_regular > div.et_pb_row.et_pb_row_1.et_pb_equal_columns > div.et_pb_column.et_pb_column_1_2.et_pb_column_3.et_pb_css_mix_blend_mode_passthrough.et-last-child > div > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_1.et_section_regular > div.et_pb_row.et_pb_row_2.et_pb_equal_columns > div.et_pb_column.et_pb_column_1_2.et_pb_column_4.et_pb_css_mix_blend_mode_passthrough > div > div > h3 > span, #services > div > div > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_5.et_pb_equal_columns.et_section_specialty > div > div.et_pb_column.et_pb_column_1_2.et_pb_column_25.et_pb_css_mix_blend_mode_passthrough.et_pb_column_single > div.et_pb_module.et_pb_text.et_pb_text_11.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_7.et_pb_with_background.et_section_regular > div > div.et_pb_column.et_pb_column_2_5.et_pb_column_30.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_22.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_7.et_pb_with_background.et_section_regular > div > div.et_pb_column.et_pb_column_2_5.et_pb_column_30.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_22.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_0.et_pb_with_background.et_section_regular.section_has_divider.et_pb_bottom_divider > div.et_pb_row.et_pb_row_0.inline-buttons-row.et_pb_equal_columns > div.et_pb_column.et_pb_column_1_2.et_pb_column_0.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_0.et_pb_text_align_left.et_pb_bg_layout_light > div > h1 > span, div > div > div > div.et_pb_section.et_pb_section_1.et_section_regular > div > div.et_pb_column.et_pb_column_1_2.et_pb_column_3.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_1.et_pb_text_align_left.et_pb_bg_layout_light > div > h1 > span, #process > div.et_pb_row.et_pb_row_2 > div > div > div > h1 > span, #process > div.et_pb_row.et_pb_row_7.molti-custom-tabs-content-4 > div.et_pb_column.et_pb_column_1_2.et_pb_column_16.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_10.et_pb_text_align_left.et_pb_bg_layout_light > div > h1 > span, div > div > div > div.et_pb_section.et_pb_section_3.et_section_regular > div > div > div.et_pb_module.et_pb_text.et_pb_text_11.et_pb_text_align_center.et_pb_bg_layout_light > div > h1 > span, div > div > div > div.et_pb_section.et_pb_section_0.et_pb_with_background.et_section_regular.section_has_divider.et_pb_bottom_divider > div.et_pb_row.et_pb_row_0.inline-buttons-row.et_pb_equal_columns > div.et_pb_column.et_pb_column_1_2.et_pb_column_0.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_0.et_pb_text_align_left.et_pb_bg_layout_light > div > h1 > span, div > div > div > div.et_pb_section.et_pb_section_0.et_section_regular > div > div.et_pb_column.et_pb_column_3_5.et_pb_column_0.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_0.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_1.et_section_specialty > div > div.et_pb_column.et_pb_column_2_3.et_pb_column_2.et_pb_specialty_column.et_pb_css_mix_blend_mode_passthrough > div.et_pb_row_inner.et_pb_row_inner_0 > div > div > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_1.et_section_specialty > div > div.et_pb_column.et_pb_column_2_3.et_pb_column_2.et_pb_specialty_column.et_pb_css_mix_blend_mode_passthrough > div.et_pb_row_inner.et_pb_row_inner_4 > div > div.et_pb_module.et_pb_text.et_pb_text_5.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_1.et_section_specialty > div > div.et_pb_column.et_pb_column_2_3.et_pb_column_2.et_pb_specialty_column.et_pb_css_mix_blend_mode_passthrough > div.et_pb_row_inner.et_pb_row_inner_2 > div > div.et_pb_module.et_pb_text.et_pb_text_3.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, #main-content > div > div > div.et_pb_section.et_pb_section_0_tb_body.et_section_regular > div > div.et_pb_column.et_pb_column_1_2.et_pb_column_0_tb_body.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_2_tb_body.molti-discussion.et_pb_text_align_left.et_pb_bg_layout_light > div, div > div > div > div.et_pb_section.et_pb_section_0.et_pb_with_background.et_section_regular.section_has_divider.et_pb_bottom_divider > div.et_pb_row.et_pb_row_0.inline-buttons-row.et_pb_equal_columns > div.et_pb_column.et_pb_column_1_2.et_pb_column_0.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_0.et_pb_text_align_left.et_pb_bg_layout_light > div > h1 > span, .et_pb_portfolio_filters li a, div > div > div > div.et_pb_section.et_pb_section_2.et_pb_with_background.et_section_regular > div > div > div.et_pb_module.et_pb_text.et_pb_text_1.et_pb_text_align_left.et_pb_bg_layout_light > div > p:nth-child(1), div > div > div > div.et_pb_section.et_pb_section_2.et_pb_with_background.et_section_regular > div > div > div.et_pb_module.et_pb_text.et_pb_text_1.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_0.home2-hero.et_pb_with_background.et_section_specialty > div > div.et_pb_column.et_pb_column_1_2.et_pb_column_0.et_pb_specialty_column.et_pb_css_mix_blend_mode_passthrough > div.et_pb_row_inner.et_pb_row_inner_0.inline-buttons-row > div > div.et_pb_module.et_pb_text.et_pb_text_0.et_pb_text_align_left.et_pb_bg_layout_light > div > h1 > span,  div > div > div > div.et_pb_section.et_pb_section_0.home2-hero.et_pb_with_background.et_section_specialty > div > div.et_pb_column.et_pb_column_1_2.et_pb_column_0.et_pb_specialty_column.et_pb_css_mix_blend_mode_passthrough > div.et_pb_row_inner.et_pb_row_inner_0.inline-buttons-row > div > div.et_pb_module.et_pb_text.et_pb_text_1.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, #services > div > div.et_pb_column.et_pb_column_1_3.et_pb_column_2.et_pb_sticky_module.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_4.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_2.home2-tabs.et_section_specialty > div > div.et_pb_column.et_pb_column_3_4.et_pb_column_6.et_pb_specialty_column.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_row_inner.et_pb_row_inner_2.molti-active-vertical-tab-content.molti-vertical-tab-content.et_pb_gutters3 > div.et_pb_column.et_pb_column_3_8.et_pb_column_inner.et_pb_column_inner_5.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_6.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_2.home2-tabs.et_section_specialty > div > div.et_pb_column.et_pb_column_3_4.et_pb_column_6.et_pb_specialty_column.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_row_inner.et_pb_row_inner_3.molti-vertical-tab-content.et_pb_gutters3.molti-active-vertical-tab-content > div.et_pb_column.et_pb_column_3_8.et_pb_column_inner.et_pb_column_inner_7.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_8.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_2.home2-tabs.et_section_specialty > div > div.et_pb_column.et_pb_column_3_4.et_pb_column_6.et_pb_specialty_column.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_row_inner.et_pb_row_inner_4.molti-vertical-tab-content.et_pb_gutters3.molti-active-vertical-tab-content > div.et_pb_column.et_pb_column_3_8.et_pb_column_inner.et_pb_column_inner_9.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_10.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_4.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_2 > div > div.et_pb_module.et_pb_text.et_pb_text_15.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_4.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_3 > div.et_pb_column.et_pb_column_1_2.et_pb_column_9.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_17.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_4.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_3 > div.et_pb_column.et_pb_column_1_2.et_pb_column_10.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_19.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_4.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_4 > div.et_pb_column.et_pb_column_1_2.et_pb_column_11.et_pb_css_mix_blend_mode_passthrough > div.et_pb_module.et_pb_text.et_pb_text_21.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_4.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_4 > div.et_pb_column.et_pb_column_1_2.et_pb_column_12.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_23.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_5.et_section_regular > div.et_pb_row.et_pb_row_5 > div > div.et_pb_module.et_pb_text.et_pb_text_26.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_6.home2-testimonials.et_pb_with_background.et_section_regular > div > div > div.et_pb_module.et_pb_text.et_pb_text_42.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_7.et_section_regular > div > div > div.et_pb_module.et_pb_text.et_pb_text_44.et_pb_text_align_left.et_pb_bg_layout_light > div > h2 > span, div > div > div > div.et_pb_section.et_pb_section_1.et_section_regular > div > div.et_pb_with_border.et_pb_column_1_3.et_pb_column.et_pb_column_2.et_pb_sticky_module.et_pb_css_mix_blend_mode_passthrough.et-last-child > div.et_pb_module.et_pb_text.et_pb_text_2.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_1.et_section_regular > div > div > div.et_pb_module.et_pb_text.et_pb_text_1.et_pb_text_align_left.et_pb_bg_layout_light > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_2.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_2 > div > div > div > h3 > span, div > div > div > div.et_pb_section.et_pb_section_1.et_section_regular > div.et_pb_row.et_pb_row_5 > div > div.et_pb_module.et_pb_text.et_pb_text_25.et_pb_text_align_center.et_pb_bg_layout_light > div > h3 > span

mark-shy-text, .molti-faq.et_pb_toggle_open .et_pb_toggle_title:before, .et_pb_menu ul li.current-menu-item a, .et_pb_menu .nav li ul.sub-menu a:hover, mark-history, .member-card li.et_pb_social_icon a.icon:before, .service-card-2 h5 > span, .why-choose-us .et-waypoint.et_pb_animation_off, .single-service-section-2 .et-waypoint:not(.et_pb_counters).et_pb_animation_off, .active-tab.et_pb_blurb h4, .process-tabs .et_pb_blurb:after, .molti-sidebar .widget_categories ul li:hover a, .molti-sidebar .widget_categories ul li:hover a:before, .et_pb_video_play:before,  .mobile_menu_bar:before, .home2-info-cards span, .home2-info-cards .et-pb-icon, .home2-service-card .et-pb-icon, .molti-vertical-tab .et-pb-icon, .home2-tabs-icon .et-pb-icon, .home2-pricing-features .et-pb-icon, .faq-tab .et-pb-icon, .molti-testimonials-page-card .et-pb-icon, .person-name-job p, .molti-blog-list-section .et_pb_post .post-meta a

{color: ' . esc_attr(get_theme_mod('accent_color_setting')) . '!important;}


/*Background Color*/
.feature .et_pb_animation_off, .et-menu-nav .et-menu li li a:hover:before, div > div > div > div.et_pb_section.et_pb_section_0.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_1.et_pb_equal_columns.et_pb_row_4col > div.et_pb_column.et_pb_column_1_4.et_pb_column_3.et_pb_css_mix_blend_mode_passthrough, div > div > div > div.et_pb_section.et_pb_section_0.et_pb_with_background.et_section_regular > div.et_pb_row.et_pb_row_1.et_pb_equal_columns.et_pb_row_4col > div.et_pb_column.et_pb_column_1_4.et_pb_column_3.et_pb_css_mix_blend_mode_passthrough, .molti-info-icon, .molti-info-icon:hover:after, .service-card-2:before, .active-link-application:before, .active-link:after, div > div > div > div.et_pb_section.et_pb_section_2.et_pb_with_background.et_section_regular.section_has_divider.et_pb_bottom_divider.et_pb_section_sticky.et_pb_section_sticky_mobile, #process .number, .blog-hero input.et_pb_searchsubmit, .molti-view-category, .et_pb_portfolio_filters li a.active, .menu-closed.menu-open:before, .molti-blog-grid .post-meta a, .et_pb_portfolio_item .post-meta a, .molti-category a, .molti-tags a, .et_pb_portofolio_pagination ul li a.active, .home2-cta, .molti-testimonial-slider .et-pb-slider-arrows a, .molti-testimonial-slider .et-pb-controllers .et-pb-active-control, .molti-blog-list a.more-link

{background-color: ' . esc_attr(get_theme_mod('accent_color_setting')) . '!important;}

/*Border Top*/
.process-divider.et_pb_divider:before 
{border-top-color: ' . esc_attr(get_theme_mod('accent_color_setting')) . '!important;}

/*Border Right*/
.molti-info-icon:hover:before, .molti-view-category:before 
{border-right-color: ' . esc_attr(get_theme_mod('accent_color_setting')) . '!important;}

/*Border Color*/
.service-card:hover, .active-link-application:before, .active-link:after, .active-link-read:after, .active-link-discussion:after, .et_pb_portfolio_filters li a, .home2-service-card:hover
{border-color: ' . esc_attr(get_theme_mod('accent_color_setting')) . '!important;}

/*For Top Bar Color*/
.molti-top-bar
{background-color: ' . esc_attr(get_theme_mod('top_bar_color_setting')) . '!important;}

</style>';
}
add_action( 'wp_head', 'molti_accent_color_change');
add_action( 'customize_register', 'starter_customize_register');


function molti_custom_js() { ?>
<script type = "text/javascript" > ///Jquery for Pricing Table COLUMN 1 on homepage
    jQuery(document).ready(function() {
        jQuery('#reveal').hide();
        jQuery('.reveal-button').click(function(e) {
            e.preventDefault();
            jQuery("#reveal").slideToggle();
            jQuery('.reveal-button');
        });
    }); 
  </script>
<script type = "text/javascript" > //Jquery for Pricing Table COLUMN 2 on homepage
    jQuery(document).ready(function() {
        // Hide the div
        jQuery('#reveal-1').hide();
        jQuery('.reveal-button-1').click(function(e) {
            e.preventDefault();
            jQuery("#reveal-1").slideToggle();
            jQuery('.reveal-button-1');
        });
    }); 
  </script>

<script type = "text/javascript" > //Jquery for Pricing Table COLUMN 3 on homepage
    jQuery(document).ready(function() {
        // Hide the div
        jQuery('#reveal-2').hide();
        jQuery('.reveal-button-2').click(function(e) {
            e.preventDefault();
            jQuery("#reveal-2").slideToggle();
            jQuery('.reveal-button-2');
        });
    }); 
  </script>




<script type = "text/javascript" > ///JQUERY FOR Custom Dropdown in Header
    jQuery(document).ready(function() {
        jQuery('.molti-custom-menu-text').show();
        jQuery('.molti-custom-menu').click(function(e) {
            e.preventDefault();
            jQuery(".molti-custom-menu-text").toggle();
        });
    });
</script>
<script type = "text/javascript" >
    jQuery(document).ready(function() {
        jQuery('.molti-custom-dropdown-content').hide();
        jQuery('.molti-custom-menu').click(function(e) {
            e.preventDefault();
            jQuery(".molti-custom-dropdown-content").toggle();
        });
    });
jQuery(document).ready(function() {
        jQuery('#et-main-area').on('click', function(event) {
            jQuery('.molti-custom-dropdown-content').hide(0);
        });
    });
  ///END HERE FOR Custom Dropdown in Header
</script>





<script>/// Molti Testimonial - Active Image Switcher for Services Page

  ///Image 1 Click
    jQuery(document).ready(function() {
        jQuery(".molti-testimonial-image-1").click(function(){
  jQuery(".molti-testimonial-image-1").addClass("active-img");
});
        jQuery(".molti-testimonial-image-1").click(function(){
  jQuery(".molti-testimonial-image-2, .molti-testimonial-image-3, .molti-testimonial-image-4").removeClass("active-img");
});
});
  ///Image 2 Click
    jQuery(document).ready(function() {
        jQuery(".molti-testimonial-image-2").click(function(){
  jQuery(".molti-testimonial-image-2").addClass("active-img");
});
        jQuery(".molti-testimonial-image-2").click(function(){
  jQuery(".molti-testimonial-image-1, .molti-testimonial-image-3, .molti-testimonial-image-4").removeClass("active-img");
});
});
  ///Image 3 Click
    jQuery(document).ready(function() {
        jQuery(".molti-testimonial-image-3").click(function(){
  jQuery(".molti-testimonial-image-3").addClass("active-img");
});
        jQuery(".molti-testimonial-image-3").click(function(){
  jQuery(".molti-testimonial-image-1, .molti-testimonial-image-2, .molti-testimonial-image-4").removeClass("active-img");
});
});
  ///Image 4 Click
    jQuery(document).ready(function() {
        jQuery(".molti-testimonial-image-4").click(function(){
  jQuery(".molti-testimonial-image-4").addClass("active-img");
});
        jQuery(".molti-testimonial-image-4").click(function(){
  jQuery(".molti-testimonial-image-1, .molti-testimonial-image-2, .molti-testimonial-image-3").removeClass("active-img");
});
});
</script>
<script>/// Molti Testimonial - Text Switches for active testimonial
  ///Image 1 Click
    jQuery(document).ready(function() {
        jQuery(".molti-testimonial-image-1").click(function(){
  jQuery(".molti-testimonial-text-1").addClass("active-text");
});
        jQuery(".molti-testimonial-image-1").click(function(){
  jQuery(".molti-testimonial-text-2, .molti-testimonial-text-3, .molti-testimonial-text-4").removeClass("active-text");
});
});
  ///Image 2 Click
    jQuery(document).ready(function() {
        jQuery(".molti-testimonial-image-2").click(function(){
  jQuery(".molti-testimonial-text-2").addClass("active-text");
});
        jQuery(".molti-testimonial-image-2").click(function(){
  jQuery(".molti-testimonial-text-1, .molti-testimonial-text-3, .molti-testimonial-text-4").removeClass("active-text");
});
});
  ///Image 3 Click
    jQuery(document).ready(function() {
        jQuery(".molti-testimonial-image-3").click(function(){
  jQuery(".molti-testimonial-text-3").addClass("active-text");
});
        jQuery(".molti-testimonial-image-3").click(function(){
  jQuery(".molti-testimonial-text-1, .molti-testimonial-text-2, .molti-testimonial-text-4").removeClass("active-text");
});
});
  ///Image 4 Click
    jQuery(document).ready(function() {
        jQuery(".molti-testimonial-image-4").click(function(){
  jQuery(".molti-testimonial-text-4").addClass("active-text");
});
        jQuery(".molti-testimonial-image-4").click(function(){
  jQuery(".molti-testimonial-text-1, .molti-testimonial-text-2, .molti-testimonial-text-3").removeClass("active-text");
});
      ///All of them
       jQuery(".molti-testimonial-image-2").click(function(){
  jQuery(".molti-testimonial-text-1").addClass("not-active-text");
});
      jQuery(".molti-testimonial-image-3").click(function(){
  jQuery(".molti-testimonial-text-1").addClass("not-active-text");
});
      jQuery(".molti-testimonial-image-4").click(function(){
  jQuery(".molti-testimonial-text-1").addClass("not-active-text");
});
});
</script>




<script>/// Single Job Page - Tabs
    jQuery(document).ready(function() {
        jQuery(".molti-careers-application-link").click(function(){
  jQuery(".molti-careers-application-link").addClass("active-link-application");
  jQuery(".molti-careers-overview-link").removeClass("active-link");
});
      jQuery(".molti-careers-overview-link").click(function(){
  jQuery(".molti-careers-overview-link").addClass("active-link");
  jQuery(".molti-careers-application-link").removeClass("active-link-application");
});
});
</script>

<script>/// Single Job Page - Working of tabs
    jQuery(document).ready(function() {
  jQuery(".application").hide();
  jQuery(".molti-careers-application-link").click(function(){
  jQuery(".application").show();
  jQuery(".role-overview").hide();
});
  jQuery(".molti-careers-overview-link").click(function(){
  jQuery(".role-overview").show();
  jQuery(".application").hide();
});
});
</script>


<script>/// Molti Pricing page - Pricing Switcher for Yearly and Monthly Button
  ///Image 1 Click
    jQuery(document).ready(function() {
        jQuery(".yearly-button").click(function(){
  jQuery(".yearly-button").addClass("molti-active-switch-button");
  jQuery(".monthly-button").removeClass("molti-active-switch-button");
});
        jQuery(".monthly-button").click(function(){
  jQuery(".monthly-button").addClass("molti-active-switch-button");
  jQuery(".yearly-button").removeClass("molti-active-switch-button");
});
});
</script>


<script>/// Pricing Page - Pricing Switcher - Working of Tables
    jQuery(document).ready(function() {
  jQuery(".yearly-pricing").hide();
  jQuery(".yearly-button").click(function(){
  jQuery(".yearly-pricing").show();
  jQuery(".monthly-pricing").hide();
});
  jQuery(".monthly-button").click(function(){
  jQuery(".monthly-pricing").show();
  jQuery(".yearly-pricing").hide();
});
});
</script>


<script>/// Molti - Single Service Page - Custom Tabs 
    jQuery(document).ready(function() {
      jQuery(".molti-custom-tab-1").click(function(){
  jQuery(".molti-custom-tab-1").addClass("active-tab");
  jQuery(".molti-custom-tab-2").removeClass("active-tab");
  jQuery(".molti-custom-tab-3").removeClass("active-tab");
  jQuery(".molti-custom-tab-4").removeClass("active-tab");
});
        jQuery(".molti-custom-tab-2").click(function(){
  jQuery(".molti-custom-tab-2").addClass("active-tab");
  jQuery(".molti-custom-tab-3").removeClass("active-tab");
  jQuery(".molti-custom-tab-4").removeClass("active-tab");
});
        jQuery(".molti-custom-tab-3").click(function(){
  jQuery(".molti-custom-tab-3").addClass("active-tab");
  jQuery(".molti-custom-tab-2").addClass("active-tab");
  jQuery(".molti-custom-tab-4").removeClass("active-tab");
});
       jQuery(".molti-custom-tab-4").click(function(){
  jQuery(".molti-custom-tab-4").addClass("active-tab");
  jQuery(".molti-custom-tab-2").addClass("active-tab");
  jQuery(".molti-custom-tab-3").addClass("active-tab");
});
});
</script>


<script>/// Molti Custom tabs - Single Service Page - For Content 
    jQuery(document).ready(function() {
  jQuery(".molti-custom-tabs-content-2").hide();
  jQuery(".molti-custom-tabs-content-3").hide();
  jQuery(".molti-custom-tabs-content-4").hide();
      
  jQuery(".molti-custom-tab-1").click(function(){
  jQuery(".molti-custom-tabs-content-1").show();
  jQuery(".molti-custom-tabs-content-2, .molti-custom-tabs-content-3, .molti-custom-tabs-content-4").hide();
});  
  jQuery(".molti-custom-tab-2").click(function(){
  jQuery(".molti-custom-tabs-content-2").show();
  jQuery(".molti-custom-tabs-content-1, .molti-custom-tabs-content-3, .molti-custom-tabs-content-4").hide();
});
  jQuery(".molti-custom-tab-3").click(function(){
  jQuery(".molti-custom-tabs-content-3").show();
  jQuery(".molti-custom-tabs-content-1, .molti-custom-tabs-content-2, .molti-custom-tabs-content-4").hide();
});
  jQuery(".molti-custom-tab-4").click(function(){
  jQuery(".molti-custom-tabs-content-4").show();
  jQuery(".molti-custom-tabs-content-1, .molti-custom-tabs-content-2, .molti-custom-tabs-content-3").hide();
});
});
</script>




<script>///For Blog Module with Text Overlay
  (function ($) {
    $(document).ready(function () {
        $(".molti-blog-latest .et_pb_post").each(function () {
          $(this).find(".entry-title, .post-meta, .post-content ").wrapAll('<div class="molti-blog-content"></div>');
        });
    });
  })(jQuery); 
</script>

<script>/// Molti -> Advanced Blog Page - Post Switcher 
    jQuery(document).ready(function() {
      jQuery(".recent-button").click(function(){
  jQuery(".recent-button").addClass("active-blog");
  jQuery(".featured-button").removeClass("active-blog");
});
    jQuery(".featured-button").click(function(){
  jQuery(".featured-button").addClass("active-blog");
  jQuery(".recent-button").removeClass("active-blog");
});
});
</script>
<script>///Working of the Switcher - To Switch content
    jQuery(document).ready(function() {
  jQuery(".recent").hide(); 
  jQuery(".recent-button").click(function(){
  jQuery(".recent").show();
  jQuery(".featured").hide();
  });
  jQuery(".featured-button").click(function(){
  jQuery(".featured").show();
  jQuery(".recent").hide();
  });
  }); 
</script>



<script>///Single Post Page Tabs
    jQuery(document).ready(function() {
      jQuery(".molti-discussion").click(function(){
  jQuery(".molti-discussion").addClass("active-link-discussion");
  jQuery(".active-link-read").removeClass("active-link-read");
});
    jQuery(".molti-read").click(function(){
  jQuery(".molti-read").addClass("active-link-read");
  jQuery(".molti-discussion").removeClass("active-link-discussion");
});
});
</script>
<script>///Single Post Page Working of tabs to change content
    jQuery(document).ready(function() {
  jQuery(".molti-comments").hide(); 
  jQuery(".molti-read").click(function(){
  jQuery(".molti-article").show();
  jQuery(".molti-comments").hide();
  });
  jQuery(".molti-discussion").click(function(){
  jQuery(".molti-comments").show();
  jQuery(".molti-article").hide();
  });
  }); 
</script>


<script>/// To Collapse Submenu in Mobile Menu
(function($) { 
    function setup_collapsible_submenus() {
        // mobile menu
        $('.mobile_nav .menu-item-has-children > a').after('<span class="menu-closed"></span>');
        $('.mobile_nav .menu-item-has-children > a').each(function() {
            $(this).next().next('.sub-menu').toggleClass('hide',1000);
        });
        $('.mobile_nav .menu-item-has-children > a + span').on('click', function(event) {
            event.preventDefault();
            $(this).toggleClass('menu-open');
            $(this).next('.sub-menu').toggleClass('hide',1000);
        });
    }
    $(window).load(function() {
        setTimeout(function() {
            setup_collapsible_submenus();
        }, 0);
    });
})(jQuery);
</script>

<script>///Code For Showcase Page
    jQuery(document).ready(function() {
  jQuery(".options").hide(0); 
  jQuery(".buy").click(function(){
  jQuery(".options").show(0);
  });
  jQuery(".close").click(function(){
  jQuery(".options").hide(0);
  });  
});
</script>

<script type = "text/javascript" >
    jQuery(document).ready(function() {
        jQuery('.info-content').hide(0);
        jQuery('.info-btn').click(function(e) {
            e.preventDefault();
            jQuery(".info-content").slideToggle(0);
        });
    }); 
  </script>
<script>    
    jQuery('.info-btn').on('click', function(e) {
      jQuery('.info-btn').toggleClass("info-button open");
      e.preventDefault();
    });///END HERE
</script>

<script>/// Code for Version 1.2 below this
</script>

<script>//JS for Vertical Tabs on Homepage V2
     jQuery(document).ready(function($) {
    $(".molti-vertical-tab").click(function(){
        var pageIndex=$(this).index();
        $next=$(".molti-vertical-tab-content").eq(pageIndex);
        $(".molti-active-vertical-tab-content").removeClass("molti-active-vertical-tab-content");
        $(".molti-active-vertical-tab").removeClass("molti-active-vertical-tab");
        $(this).addClass("molti-active-vertical-tab");
        $next.addClass("molti-active-vertical-tab-content");
    })
})
</script>



<script>//FAQ Tabs on the FAQ Page
     jQuery(document).ready(function($) {
    $(".faq-tab").click(function(){
        var pageIndex=$(this).index();
        $next=$(".faq-content").eq(pageIndex);
        $(".active-faq-content").removeClass("active-faq-content");
        $(".active-faq-tab").removeClass("active-faq-tab");
        $(this).addClass("active-faq-tab");
        $next.addClass("active-faq-content");
    })
})
</script>



<script>/// Creating a Pages toggle on Showcase Page - for Content
    jQuery(document).ready(function() {
  jQuery(".the-new-pages-content").hide();      
  jQuery(".the-new").click(function(){
  jQuery(".the-new-pages-content").show();
  jQuery(".all-pages-content").hide();
});
		jQuery(".all-pages").click(function(){
  jQuery(".all-pages-content").show();
  jQuery(".the-new-pages-content").hide();
});
});
</script>



<script>//// Showcase Page - Active Indication
    jQuery(document).ready(function() {
      jQuery(".the-new").click(function(){
  jQuery(this).addClass("active-pages-toggle");
  jQuery(".all-pages").removeClass("active-pages-toggle");
});
		   jQuery(".all-pages").click(function(){
  jQuery(this).addClass("active-pages-toggle");
  jQuery(".the-new").removeClass("active-pages-toggle");
});
});
</script>




<?php }
add_action('wp_footer', 'molti_custom_js', 100);


//======================================================================
// CUSTOM DASHBOARD
//======================================================================
// ADMIN FOOTER TEXT
function molti_remove_footer_admin () {
    echo "Molti Child theme by SamarJ";
} 
add_action('wp_dashboard_setup', 'molti_my_custom_dashboard_widgets');

function molti_my_custom_dashboard_widgets() {
global $wp_meta_boxes;

wp_add_dashboard_widget('molti_custom_help_widget', 'Molti Child Theme', 'molti_custom_dashboard_help');
}

function molti_custom_dashboard_help() {
echo '<p>Thank you for Purchasing <strong>Molti</strong> Child Theme by SamarJ. If you have any problem while using it use the links below for Support:
<ul>
  <li><a href="https://docs.samarj.com/molti" target="_blank">Documentations ➜</a></li>
  <li><a href="https://samarj.com/contact" target="_blank">Contact Us ➜</a></li>
  <li><a href="https://headwayapp.co/molti-changelog" target="_blank">Molti Changelog ➜</a></li>
</ul></p>';
}
//END


?>